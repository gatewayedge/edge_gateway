#!/usr/bin/env bash
set -euo pipefail

########################################
# 配置（按你的路径填写即可）
########################################

#APP_PATH="/Users/zhouxiaolong/Library/Developer/Xcode/DerivedData/edgeslink-aovbedwhnfqcdvglueotbdxlxrhy/Build/Products/Release"
APP_PATH="/Users/zhouxiaolong/Library/Developer/Xcode/DerivedData/edgeslink-aovbedwhnfqcdvglueotbdxlxrhy/Build/Products/Release/edgeslink.app"

TEAM_ID="6SFZ7535WB"
DEVID_APP_IDENTITY="Developer ID Application: xiaolong zhou (${TEAM_ID})"

ZIP_PATH="/Users/zhouxiaolong/work/macios/edgeslink/edgeslink.zip"
ENT_PLIST="/Users/zhouxiaolong/work/macios/edgeslink/edgeslink/release.entitlements"

KEYCHAIN_PROFILE="notary-profile"   # 你本地 notarytool 配置

# 是否强制重签 / 强制重新公证（可通过环境变量覆盖）
need_resign=true
need_notarize=true


########################################
# 1. 基础检查
########################################

echo "== 基础检查 =="
[ -d "${APP_PATH}" ] || { echo "❌ 找不到 APP：${APP_PATH}"; exit 1; }

security find-identity -v -p codesigning | grep -F "${DEVID_APP_IDENTITY}" >/dev/null \
  || { echo "❌ 钥匙串中未找到证书：${DEVID_APP_IDENTITY}"; exit 1; }

echo "== 检查签名身份 =="
if codesign -dv --verbose=4 "${APP_PATH}" 2>&1 | grep -q "^Authority=Developer ID Application:"; then
  echo "· 已是 Developer ID Application 签名 → 默认跳过重签"
  need_resign=${FORCE_RESIGN:-0}
else
  need_resign=1
fi

echo "== 检查是否已装订（stapled） =="
if xcrun stapler validate "${APP_PATH}" >/dev/null 2>&1; then
  echo "· 已装订 → 默认跳过公证"
  need_notarize=${FORCE_NOTARIZE:-0}
else
  need_notarize=1
fi


########################################
# 2. 重新签名（如需要）
########################################

if [ "${need_resign}" = "1" ]; then
  echo "== 导出/修正 entitlements =="

  mkdir -p "$(dirname "${ENT_PLIST}")"

  # 尝试从现有签名导出 entitlements（:- 强制 XML，如没有则失败）
  if codesign -d --entitlements :- "${APP_PATH}" > "${ENT_PLIST}" 2>/dev/null; then
    echo "· 已成功导出现有 entitlements → ${ENT_PLIST}"
  else
    echo "· App 无现有 entitlements → 写入最小 entitlements"
    cat > "${ENT_PLIST}" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "https://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <!-- Release 禁止调试 -->
  <key>com.apple.security.get-task-allow</key>
  <false/>
</dict>
</plist>
PLIST
  fi

  # 强制 XML 格式 & 确保 get-task-allow = false
  plutil -convert xml1 "${ENT_PLIST}"
  /usr/libexec/PlistBuddy -c "Set :com.apple.security.get-task-allow false" "${ENT_PLIST}" 2>/dev/null || \
  /usr/libexec/PlistBuddy -c "Add :com.apple.security.get-task-allow bool false" "${ENT_PLIST}"

  echo "== 深度重签（Hardened Runtime + Timestamp） =="

  # 先重签所有可执行文件（避免后面 deep verify 异常）
  while IFS= read -r -d '' BIN; do
    echo "· 重签内部可执行文件：$BIN"
    codesign --force --options runtime --timestamp \
             --entitlements "${ENT_PLIST}" \
             --sign "${DEVID_APP_IDENTITY}" \
             "$BIN"
  done < <(find "${APP_PATH}" -type f -perm -111 -print0)

  echo "· 重签根 app bundle"
  codesign --force --options runtime --timestamp \
           --entitlements "${ENT_PLIST}" \
           --sign "${DEVID_APP_IDENTITY}" \
           "${APP_PATH}"

  echo "· 验证（deep verify）"
  codesign --verify --deep --strict --verbose=2 "${APP_PATH}"

  # 重签后需要重新公证
  need_notarize=1
fi


########################################
# 3. 公证 & Staple（如需要）
########################################

if [ "${need_notarize}" = "1" ]; then
  echo "== 打包并提交公证 =="
  rm -f "${ZIP_PATH}"
  /usr/bin/ditto -c -k --keepParent "${APP_PATH}" "${ZIP_PATH}"

  echo "· 提交到 Notary Service（等待结果）"
  xcrun notarytool submit "${ZIP_PATH}" \
    --keychain-profile "${KEYCHAIN_PROFILE}" \
    --team-id "${TEAM_ID}" \
    --wait

  echo "· Staple"
  xcrun stapler staple "${APP_PATH}"
else
  echo "· 跳过公证：app 未改变 & 已装订"
fi


########################################
# 4. 最终验证
########################################

echo "== 最终验证 =="
codesign --verify --deep --strict --verbose=4 "${APP_PATH}"
spctl -a -vv "${APP_PATH}" || true

echo "🎉 完成！可安全分发 EdgesLink.app"
